/** @jsx jsx */
import { React, AllWidgetProps, jsx } from 'jimu-core'
import { IMConfig } from '../config'
import { JimuMapView, JimuMapViewComponent } from 'jimu-arcgis'

import defaultMessages from './translations/default'

interface IState {
  jimuMapView: JimuMapView
  latitude: string
  longitude: string
  scale: number
}

export default class Widget extends React.PureComponent<
AllWidgetProps<IMConfig>,
IState
> {
  nls = (id: string) => {
    return this.props.intl
      ? this.props.intl.formatMessage({
        id: id,
        defaultMessage: defaultMessages[id]
      })
      : id
  }

  constructor (props) {
    super(props)

    // Persist the MapView, lat, long and scale
    this.state = {
      jimuMapView: null,
      latitude: '',
      longitude: '',
      scale: 0
    }
  }

  // Function that watches the extent change
  // Persists the lat, long, and scale information
  activeViewChangeHandler = (jmv: JimuMapView) => {
    if (jmv) {
      console.log('jmv', jmv)
      this.setState({
        jimuMapView: jmv
      })

      jmv.view.watch('extent', () => {
        this.setState({
          latitude: this.state.jimuMapView.view.center.latitude.toFixed(3),
          longitude: this.state.jimuMapView.view.center.longitude.toFixed(3),
          scale: Math.round(this.state.jimuMapView.view.scale * 1) / 1
        })
      })
    }
  }

  render () {
    return (
      <div className='widget-demo jimu-widget m-2'>
        {this.props.useMapWidgetIds &&
          this.props.useMapWidgetIds.length === 1 && (
            <JimuMapViewComponent
              useMapWidgetId={this.props.useMapWidgetIds?.[0]}
              onActiveViewChange={this.activeViewChangeHandler}
            />
        )}
        <p>{this.nls('widgetTitle')}</p>
        <p>{this.nls('latitudeLongitude')}: {this.state.latitude}, {this.state.longitude}</p>
        <p>{this.nls('scale')}: {this.state.scale}</p>
      </div>
    )
  }
}
