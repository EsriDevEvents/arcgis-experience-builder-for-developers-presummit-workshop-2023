export default {
  _widgetLabel: 'basic-widget-pt2',
  widgetTitle: 'Developer Summit 2023',
  latitudeLongitude: 'Latitude/Longitude',
  scale: 'Scale'
}
