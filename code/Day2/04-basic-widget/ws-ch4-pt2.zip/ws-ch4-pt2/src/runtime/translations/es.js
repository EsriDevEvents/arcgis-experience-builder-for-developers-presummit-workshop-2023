define({
  _widgetLabel: 'DS2022 in Spanish',
  widgetTitle: 'Spanish Title'
});
