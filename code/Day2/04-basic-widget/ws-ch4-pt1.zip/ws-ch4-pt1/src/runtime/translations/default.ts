export default {
  _widgetLabel: 'basic-widget-pt1',
  widgetTitle: 'Developer Summit 2023'
}
