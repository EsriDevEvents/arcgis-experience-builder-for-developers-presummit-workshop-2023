/** @jsx jsx */
import { React, AllWidgetProps, jsx } from 'jimu-core'
import { IMConfig } from '../config'
import { JimuMapView, JimuMapViewComponent } from 'jimu-arcgis'

import defaultMessages from './translations/default'

interface IState {
  jimuMapView: JimuMapView
}

export default class Widget extends React.PureComponent<
AllWidgetProps<IMConfig>,
IState
> {
  nls = (id: string) => {
    return this.props.intl
      ? this.props.intl.formatMessage({
        id: id,
        defaultMessage: defaultMessages[id]
      })
      : id
  }

  constructor (props) {
    super(props)

    this.state = {
      jimuMapView: null
    }
  }

  // Function that persists the MapView
  activeViewChangeHandler = (jmv: JimuMapView) => {
    if (jmv) {
      console.log('jmv', jmv)
      this.setState({
        jimuMapView: jmv
      })
    }
  }

  render () {
    return (
      <div className='widget-demo jimu-widget m-2'>
        {this.props.useMapWidgetIds &&
          this.props.useMapWidgetIds.length === 1 && (
            <JimuMapViewComponent
              useMapWidgetId={this.props.useMapWidgetIds[0]}
              onActiveViewChange={this.activeViewChangeHandler}
            />
        )}
        <p>{this.nls('widgetTitle')}</p>
        <p>exampleConfigProperty: {this.props.config.exampleConfigProperty}</p>
      </div>
    )
  }
}
