System.register([], function (_export) {
  return {
    execute: function () {
      _export({
        // the strings
        _widgetLabel: "Translated Widget Name",
        str1: "Translated String 1",
      });
    },
  };
});
