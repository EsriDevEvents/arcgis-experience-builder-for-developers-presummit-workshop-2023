export default {
  _widgetLabel: "My Widget",
  str1: "String 1",
};
