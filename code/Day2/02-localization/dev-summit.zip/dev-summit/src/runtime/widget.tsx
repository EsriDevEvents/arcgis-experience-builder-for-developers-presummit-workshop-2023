import { React, AllWidgetProps, FormattedMessage } from 'jimu-core'
import { IMConfig } from '../config'
import defaultMessages from './translations/default'

const Widget = (props: AllWidgetProps<IMConfig>) => {
  return (
    <div className="widget-demo jimu-widget m-2">
      <p>
        <FormattedMessage id="str1" defaultMessage={defaultMessages.str1} />
      </p>
      <p>exampleConfigProperty: {props.config.exampleConfigProperty}</p>
    </div>
  )
}

export default Widget
