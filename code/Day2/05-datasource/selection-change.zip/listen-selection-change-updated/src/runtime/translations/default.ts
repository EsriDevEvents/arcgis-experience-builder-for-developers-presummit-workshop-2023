export default {
  _widgetLabel: 'Selection change updated',
  widgetHeading:
    'This widget shows how to listen to the selection change of a datasource.',
  connectDS: 'Please configure the data source.',
};
