System.register([], function (_export) {
  return {
    execute: function () {
      _export({
        // the strings
        _widgetLabel: 'Cambio de selección actualizado',
        fieldLabel: 'Seleccione un campo',
        widgetHeading:
          'Este widget muestra cómo escuchar el cambio de selección de una fuente de datos.',
        connectDS: 'Configure el origen de datos.',
      });
    },
  };
});
