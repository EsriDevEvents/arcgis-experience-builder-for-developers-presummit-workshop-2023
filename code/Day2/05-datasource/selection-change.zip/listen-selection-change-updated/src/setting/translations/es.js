System.register([], function (_export) {
  return {
    execute: function () {
      _export({
        // the strings
        _widgetLabel: 'Cambio de selección actualizado',
        fieldLabel: 'Seleccione un campo',
      });
    },
  };
});
