export default {
  _widgetLabel: 'Selection change updated',
  fieldLabel: 'Select a label field',
};
